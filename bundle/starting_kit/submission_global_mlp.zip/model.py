import numpy as np
import torch
import torch.nn as nn

NWALLP = 260774
COL_MINF, COL_AOA, COL_PI = 6, 7, 8
EPS = 1e-6

# Global MLP, Peter et al. 2025 ("ONERA's CRM WBPN database for machine learning activities..."),
# section 5.1 -- exact hidden layer sizes, 200-epoch training budget, MSE loss. Same architecture
# and training loop as utils/paper_global_mlp.py in the project repo (already validated there),
# adapted to Codabench's fit(X, y)/predict(X) interface.
HIDDEN = (75, 120, 1226, 16490)
N_EPOCHS = 200
BATCH = 32
LR = 1e-3
SEED = 0

# The final Linear(16490, NWALLP) layer alone is ~4.3B parameters (~17GB fp32 weights; Adam's two
# moment buffers plus gradients roughly quadruple that -- ~35GB peak for that one layer during
# training). This is why utils/paper_global_mlp.py needed a big-memory CPU node
# (utils/sbatch_paper_global_mlp_cpu.sh) instead of the cluster's own GPU (only ~16GB VRAM,
# confirmed OOM there on this exact architecture). Forcing CPU here for the same reason --
# Codabench's GPU allocation (if any) is unknown from here and a repeat OOM is the likelier
# outcome than it happening to have enough VRAM. Codabench's worker RAM is also unknown, so this
# remains a real risk either way, just the better-evidenced one of the two.
DEVICE = torch.device('cpu')


class GlobalMLP(nn.Module):
    def __init__(self, hidden, n_out):
        super().__init__()
        layers, d = [], 3
        for h in hidden:
            layers += [nn.Linear(d, h), nn.LeakyReLU(0.01)]
            d = h
        layers += [nn.Linear(d, n_out)]
        self.net = nn.Sequential(*layers)

    def forward(self, c):
        return self.net(c)


class Model:
    """ fit()/predict() receive the full pointwise [n_sims*NWALLP, 9] arrays Codabench's
    ingestion program passes -- conditions are extracted internally (one row per simulation,
    columns 6:9) since this is a field regressor, not a pointwise one. """

    def __init__(self):
        self.cond_mean = None
        self.cond_std = None
        self.y_mean = None
        self.y_std = None
        self.net = None

    def fit(self, X, y):
        torch.manual_seed(SEED)
        np.random.seed(SEED)

        n_train = X.shape[0] // NWALLP
        train_conds = np.asarray(X[::NWALLP, COL_MINF:COL_PI + 1], dtype=np.float32)
        Y_train = np.asarray(y, dtype=np.float32).reshape(n_train, NWALLP)

        self.cond_mean = train_conds.mean(axis=0)
        self.cond_std = train_conds.std(axis=0)
        self.cond_std[self.cond_std == 0] = 1.0
        conds_sc = (train_conds - self.cond_mean) / self.cond_std

        self.y_mean = float(Y_train.mean())
        self.y_std = float(Y_train.std()) + EPS
        Y_train_sc = (Y_train - self.y_mean) / self.y_std

        C_train = torch.tensor(conds_sc, dtype=torch.float32, device=DEVICE)
        Y_train_t = torch.tensor(Y_train_sc, dtype=torch.float32, device=DEVICE)

        self.net = GlobalMLP(HIDDEN, NWALLP).to(DEVICE)
        opt = torch.optim.Adam(self.net.parameters(), lr=LR)
        loss_fn = nn.MSELoss()

        self.net.train()
        for epoch in range(N_EPOCHS):
            perm = torch.randperm(n_train)
            for i in range(0, n_train, BATCH):
                idx = perm[i:i + BATCH]
                pred = self.net(C_train[idx])
                loss = loss_fn(pred, Y_train_t[idx])
                opt.zero_grad()
                loss.backward()
                opt.step()
        return self

    def predict(self, X):
        test_conds = np.asarray(X[::NWALLP, COL_MINF:COL_PI + 1], dtype=np.float32)
        conds_sc = (test_conds - self.cond_mean) / self.cond_std

        self.net.eval()
        with torch.no_grad():
            C = torch.tensor(conds_sc, dtype=torch.float32, device=DEVICE)
            out = self.net(C).cpu().numpy()

        y_pred = out * self.y_std + self.y_mean
        return y_pred.reshape(-1).astype(np.float64)
